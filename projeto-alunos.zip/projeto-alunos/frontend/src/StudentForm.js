import React, { useState } from 'react';
import axios from 'axios';

function StudentForm({ onAddStudent }) {
    const [name, setName] = useState('');
    const [grades, setGrades] = useState(Array(5).fill(0));
    const [attendance, setAttendance] = useState(0);

    // Função para lidar com as alterações nas notas
    const handleGradeChange = (index, value) => {
        const newGrades = [...grades];
        newGrades[index] = parseFloat(value) || 0;  // Garante que o valor seja numérico
        setGrades(newGrades);
    };

    // Função para lidar com o envio do formulário
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:3001/students', { name, grades, attendance: parseFloat(attendance) });
            onAddStudent();  // Chama a função callback para adicionar o aluno
        } catch (error) {
            console.error('Erro ao adicionar aluno', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <input 
                    type="text" 
                    placeholder="Nome do aluno" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                />
            </div>
            {grades.map((grade, index) => (
                <div key={index}>
                    <input 
                        type="number" 
                        placeholder={`Nota ${index + 1}`} 
                        value={grade} 
                        onChange={(e) => handleGradeChange(index, e.target.value)} 
                    />
                </div>
            ))}
            <div>
                <input 
                    type="number" 
                    placeholder="Frequência (%)" 
                    value={attendance} 
                    onChange={(e) => setAttendance(e.target.value)} 
                />
            </div>
            <button type="submit">Adicionar Aluno</button>
        </form>
    );
}

export default StudentForm;
