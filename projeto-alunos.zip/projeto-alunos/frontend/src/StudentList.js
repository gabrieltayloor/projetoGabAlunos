import React, { useEffect, useState } from 'react';
import axios from 'axios';

function StudentList() {
    const [students, setStudents] = useState([]);

    useEffect(() => {
        fetchStudents();
    }, []);

    const fetchStudents = async () => {
        const response = await axios.get('http://localhost:3001/students');
        setStudents(response.data);
    };

    return (
        <div>
            <h2>Lista de Alunos</h2>
            <ul>
                {students.map((student, index) => (
                    <li key={index}>
                        {student.name} - Média: {student.average.toFixed(2)} - Frequência: {student.attendance}%
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default StudentList;