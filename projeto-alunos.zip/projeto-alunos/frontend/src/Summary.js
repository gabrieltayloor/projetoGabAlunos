import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Summary() {
    const [summary, setSummary] = useState(null);

    useEffect(() => {
        fetchSummary();
    }, []);

    const fetchSummary = async () => {
        try {
            const response = await axios.get('http://localhost:3001/summary');
            setSummary(response.data);
        } catch (error) {
            console.error('Erro ao buscar resumo:', error);
        }
    };

    if (!summary) return <div>Carregando...</div>;

    return (
        <div>
            <h2>Resumo da Turma</h2>

            {/* Médias por Disciplina */}
            <h3>Médias por Disciplina</h3>
            <ul>
                {summary.classAverages.map((avg, index) => (
                    <li key={index}>Disciplina {index + 1}: {avg.toFixed(2)}</li>
                ))}
            </ul>

            {/* Alunos com Média Acima da Média da Turma */}
            <h3>Alunos com Média Acima da Média da Turma</h3>
            <ul>
                {summary.aboveAverageStudents.map((student, index) => (
                    <li key={index}>{student.name}</li>
                ))}
            </ul>

            {/* Alunos com Frequência Abaixo de 75% */}
            <h3>Alunos com Frequência Abaixo de 75%</h3>
            <ul>
                {summary.lowAttendanceStudents.map((student, index) => (
                    <li key={index}>{student.name}</li>
                ))}
            </ul>
        </div>
    );
}

export default Summary;
