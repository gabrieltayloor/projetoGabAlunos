import React, { useState } from 'react';
import StudentForm from './StudentForm';
import StudentList from './StudentList';
import Summary from './Summary';

function App() {
    const [updateList, setUpdateList] = useState(false);

    const handleAddStudent = () => {
        // Atualiza a lista de alunos quando um novo aluno é adicionado
        setUpdateList(!updateList);
    };

    return (
        <div className="App">
            <h1>Gestão de Alunos</h1>
            <StudentForm onAddStudent={handleAddStudent} />
            <StudentList key={updateList} />
            <Summary />
        </div>
    );
}

export default App;