const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const students = [];

// Endpoint para adicionar um aluno
app.post('/students', (req, res) => {
    const { name, grades, attendance } = req.body;
    students.push({ name, grades, attendance });
    res.status(201).json({ message: 'Aluno adicionado com sucesso' });
});

// Endpoint para obter todos os alunos e calcular médias
app.get('/students', (req, res) => {
    const studentsWithAverages = students.map(student => {
        const average = student.grades.reduce((a, b) => a + b, 0) / student.grades.length;
        return { ...student, average };
    });
    res.json(studentsWithAverages);
});

// Endpoint para obter o resumo da turma
app.get('/summary', (req, res) => {
    const numSubjects = 5;
    const totalGrades = Array(numSubjects).fill(0);
    let studentsCount = students.length;

    students.forEach(student => {
        student.grades.forEach((grade, index) => {
            totalGrades[index] += grade;
        });
    });

    const classAverages = totalGrades.map(total => total / studentsCount);

    const aboveAverageStudents = studentsWithAverages.filter(student => student.average > classAverages.reduce((a, b) => a + b) / numSubjects);
    const lowAttendanceStudents = students.filter(student => student.attendance < 75);

    res.json({
        classAverages,
        aboveAverageStudents,
        lowAttendanceStudents
    });
});

// Inicie o servidor
app.listen(3001, () => console.log('Backend rodando na porta 3001'));