# Sistema de Gestão de Alunos

Este é um sistema de gestão de notas e frequência de alunos, desenvolvido para ajudar o professor Carlos a organizar os dados acadêmicos de seus alunos. O sistema permite adicionar alunos, registrar notas em cinco disciplinas e calcular automaticamente a média de cada aluno, a média da turma e a frequência dos alunos.

## Funcionalidades

- Adicionar alunos com notas para cinco disciplinas e frequência.
- Calcular a média de cada aluno e a média geral da turma por disciplina.
- Listar alunos com média acima da média da turma e alunos com frequência abaixo de 75%.
- Interface amigável desenvolvida em React.
- Back-end simples com Node.js e Express.

## Pré-requisitos

- *Node.js* (versão LTS recomendada): [https://nodejs.org/](https://nodejs.org/)
- *npm* (instalado com o Node.js)

## Instalação e Execução

### 1. Clonar o Repositório

```bash
git clone https://github.com/seu-usuario/nome-do-repositorio.git
cd nome-do-repositorio

2. Configuração do Back-End

cd backend
npm install
node index.js

O back-end será executado em http://localhost:3001.

3. Configuração do Front-End

Abra um novo terminal, navegue até frontend e execute:

cd ../frontend
npm install
npm start

O front-end será executado em http://localhost:3000.

4. Testando o Sistema

	•	Acesse http://localhost:3000 no navegador.
	•	Adicione alunos e visualize as médias e frequência da turma.

Estrutura do Projeto

nome-do-repositorio/
├── backend/                  # Servidor Node.js
├── frontend/                 # Aplicação React
├── README.md                 # Documentação do projeto
└── .gitignore                # Arquivos ignorados pelo Git

Decisões de Projeto

	•	Componentes: Dividimos o front-end em componentes React (StudentForm, StudentList, Summary) para modularidade.
	•	API Simples: O back-end usa Node.js e Express com armazenamento temporário. Um banco de dados poderia ser integrado para persistência de dados.

Possíveis Melhorias

	•	Adicionar banco de dados para persistência de dados.
	•	Implementar autenticação para segurança.
	•	Adicionar validação de dados e testes para maior confiabilidade.

Este README.md contém instruções essenciais para configurar e rodar o projeto, além de informações sobre a estrutura e decisões de projeto.